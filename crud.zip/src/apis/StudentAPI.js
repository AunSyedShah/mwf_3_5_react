import axios from 'axios';

const API_URL = 'https://6659ab03de346625136d6ff4.mockapi.io/api/students';

// Function to fetch all students
export const getAllStudents = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Function to create a new student
export const createStudent = async (studentData) => {
  try {
    const response = await axios.post(API_URL, studentData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Function to update a student
export const updateStudent = async (studentId, updatedData) => {
  try {
    const response = await axios.put(`${API_URL}/${studentId}`, updatedData);
    return response.data;
  } catch (error) {
    throw error;
  }
};

// Function to delete a student
export const deleteStudent = async (studentId) => {
  try {
    const response = await axios.delete(`${API_URL}/${studentId}`);
    return response.data;
  } catch (error) {
    throw error;
  }
};
