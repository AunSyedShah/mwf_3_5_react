import { createContext } from "react";


export const StudentContext = createContext();