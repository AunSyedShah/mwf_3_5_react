import { useFormik } from "formik";
import { useParams } from "react-router-dom";
import { useSearchParams } from "react-router-dom";


const UpdateStudent = (props) => {
    let [searchParams, setSearchParams] = useSearchParams();
    const std_id = searchParams.get("std_id");
    const std_name = searchParams.get("std_name");
    const is_paid = searchParams.get("is_paid")

    const formik = useFormik(
        {
            initialValues: {
                stud_id: std_id,
                stud_name: std_name,
                is_paid: is_paid
            },
            onSubmit: (values) => {
                const data = {
                    stud_id: values.stud_id,
                    stud_name: values.stud_name,
                    is_paid: values.is_paid
                }
                async function add_student() {
                    const response = await axios.post("https://6659ab03de346625136d6ff4.mockapi.io/api/students", data);
                    if (response.status == 201) {
                        setStudents([...students, response.data]);
                        values.stud_name = '';
                        values.stud_id = '';
                        values.is_paid = '';
                    }
                }
                add_student();
            }
        }
    )
    return (
        <div>
            <form className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4" onSubmit={formik.handleSubmit}>
                <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="studentID">
                        Student ID
                    </label>
                    <input
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        id="studentID"
                        type="text"
                        placeholder="Enter Student ID"
                        name="stud_id"
                        value={formik.values.stud_id}
                        onChange={formik.handleChange}
                        disabled
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="studentName">
                        Student Name
                    </label>
                    <input
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        id="studentName"
                        type="text"
                        placeholder="Enter Student Name"
                        name="stud_name"
                        value={formik.values.stud_name}
                        onChange={formik.handleChange}
                    />
                </div>
                <div className="mb-6">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="isPaid">
                        Is Paid
                    </label>
                    <input
                        className="mr-2 leading-tight"
                        id="isPaid"
                        type="checkbox"
                        name="is_paid"
                        checked={formik.values.is_paid}
                        onChange={formik.handleChange}
                    />
                    <label className="text-sm text-gray-700" htmlFor="isPaid">
                        Paid
                    </label>
                </div>
                <div className="flex items-center justify-between">
                    <button
                        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                        type="submit"
                    >
                        Update
                    </button>
                </div>
            </form>
        </div>
    )
}

export default UpdateStudent;