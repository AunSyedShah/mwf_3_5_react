const Layout = (props) => {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-gray-800 text-white py-4 px-6">
        <h1 className="text-xl font-bold">I am a header</h1>
      </header>
      <main className="flex-grow">
        {props.children}
      </main>
      <footer className="bg-gray-800 text-white py-4 px-6">
        <h1 className="text-xl font-bold">I am a footer</h1>
      </footer>
    </div>
  );
};

export default Layout;
