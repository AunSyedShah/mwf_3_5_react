import React, { useState, useEffect } from "react";
import StudentCard from "./components/student_card";
import AddStudent from "./components/add_student";
import { getAllStudents } from "./apis/StudentAPI";
import { StudentContext } from "./context/studentContext.js";

export default function App() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const fetchedStudents = await getAllStudents();
        setStudents(fetchedStudents);
      } catch (error) {
        console.error("Error fetching students:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="bg-slate-200 p-4">
      <StudentContext.Provider value={{ students, setStudents }}>
        <AddStudent />
        <div className="grid grid-cols-3 gap-4">
          {
            students.map((student, index) => (
              <StudentCard state={{ student }} key={index} />
            ))
          }
        </div>
      </StudentContext.Provider>
    </div>
  );
}
