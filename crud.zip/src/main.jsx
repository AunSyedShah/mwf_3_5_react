import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/layout.jsx'
import UpdateStudent from './components/update.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <Layout>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App />} />
        <Route path='/update' element={<UpdateStudent />} />
        <Route path='/about' element={
          <div>
            <h1 className='text-6xl'>I am About</h1>
          </div>
        } />
      </Routes>
    </BrowserRouter>
  </Layout>
)
